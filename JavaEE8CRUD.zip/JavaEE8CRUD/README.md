

APLICACION DE PEDIDOS <br>
APLIACCION CON GESTION DE CLIENTES, PRODUCTOS Y PEDIDOS


LISTADO DE PRODUCTOS
 <img src="imagenes_repositorio/listado_prods.png" alt="ventas .png" width="1000" height="600">

 FORMULARIO DE CREACION Y EDICION DE PRODUCTOS
 <img src="imagenes_repositorio/edicion_creacion.png" alt="ventas .png" width="1000" height="600">




5-	Recopilación de requerimientos técnicos <br>
-	Entorno de Desarrollo: Netbeans, jdk 1.8, JAVA EE 8, GLASSFISH 5 <br>
-	Base de datos: ORACLE 18C EXPRESS, SQLDEVELOPER.<br>
-	Lenguaje de programación: java EE, JAVASCRIPT, JQUERY  <br>
-	ESTILOS: BOOTSTRAP <br>

